1st compile the code ==>  javac TicTacToe.java
next run the code ==> java TicTacToe

*By clicking players can play on their turns
*After a player winning or after the match is draw, the game can be reset.