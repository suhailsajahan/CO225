public class TicTacToe {
    public static void main(String[] args) {
       System system = new System();
       Frame frame = new Frame();
       Action action = new Action(system, frame);
   }
   
}
