public enum Number {
    player1,player2
}
